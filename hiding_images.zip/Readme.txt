For demo purposes, run:
>> hide_image('pano.jpg','map1.bmp','faces.bmp','house.jpg');

>> extract_image('embedded.png');

Works for gray and colored images.

Haven't tried various image formats, but it does work for jpeg, png and bitmap images.

specifications:

1. Number of input images to be hidden limited to 255.
2. Input images must have row size(height of image) less than 32767 and column size(length of image) less than 65535.