function hide_image(src_img,varargin)
% Hide Image : This code hides image(s) inside one larger image.
%
% Syntax: hide_image(source_image_file_name,images_filenames_to_be_hidden)
%
% Examples:
% 
% >> hide_image('pano.jpg','map1.bmp','faces.bmp');
% Used 74.3117 percent of the source image. Embedded Image saved as : 'embedded.png' in the current directory.
%
% >> hide_image('pano.jpg','map1.bmp','faces.bmp','house.jpg');
% Used 93.7543 percent of the source image. Embedded Image saved as : 'embedded.png' in the current directory.
% 
% Error will be reported with stats:
% >> hide_image('pano.jpg','map1.bmp','faces.bmp','house.jpg','carey.jpg');
% ??? Error using ==> hide_image at ..
% Too Many Images or Too Big Image for Hiding [Used 105.9668 percent of the source image].
% So, keep the usage of the source image within 100 percent for sucessful operation.

%---------- Inputs---------------------------------------------------------
num_of_images=nargin-1;
all_images=[];
image1props=[];
szim=zeros(num_of_images,3);
check_limit=0;
for i=1:num_of_images
    b=double(imread(char(varargin(i))));
    szim(i,1)=size(b,1);szim(i,2)=size(b,2);szim(i,3)=size(b,3);
    check_limit=check_limit+size(b,1)*size(b,2)*size(b,3);
    all_images=[all_images reshape(b,1,size(b,1)*size(b,2)*size(b,3))];
end
for i=1:num_of_images
    image1props=[image1props reshape([floor(szim(i,3)/3) binary_vector(szim(i,1))' zeros(1,15-length(binary_vector(szim(i,1)))) binary_vector(szim(i,2))' zeros(1,16-length(binary_vector(szim(i,2))))],8,4)];
end
next=4*num_of_images+1;
%--------------------------------------------------------------------------
a=double(imread(src_img));
percent_of_img_used=(100*8*(check_limit+4*num_of_images+1))/(size(a,1)*size(a,2)*size(a,3));
if percent_of_img_used >100
    display_text=['Too Many Images or Too Big Image for Hiding [Used ' num2str(percent_of_img_used) ' percent of the source image].'];
    error(display_text);
end
display_text = ['Used ' num2str(percent_of_img_used) ' percent of the source image. Embedded Image saved as : ''embedded.png'' in the current directory.'];
disp(display_text);

a2=[reshape(a,1,size(a,1)*size(a,2)*size(a,3)) zeros(1,8-rem(size(a,1)*size(a,2)*size(a,3),8))];
a11=2.*floor(reshape(a2,8,length(a2)/8)/2);
a11(:,1)=a11(:,1) + binary_vector(num_of_images);
a11(:,2:next)=a11(:,2:next) + image1props;
for j=1:num_of_images
    b1=all_images(next-4*num_of_images:next-4*num_of_images-1+szim(j,1)*szim(j,2)*szim(j,3));
    for i=1:length(b1)
        a11(:,i+next)=a11(:,i+next)+ binary_vector(b1(i));
    end
    next=next+szim(j,1)*szim(j,2)*szim(j,3);
end
a111=reshape(a11,1,size(a11,1)*size(a11,2)*size(a11,3));
a111=a111(1:end-(8-rem(size(a,1)*size(a,2)*size(a,3),8)));
a22=reshape(a111,size(a,1),size(a,2),size(a,3));
imwrite(uint8(a22),'embedded.png');
%--------------------------------------------------------------------------

function out = binary_vector(in)
% This code converts unsigned integer number into Binary vector.
% It is used in this project for conversion into binary numbers of 8-bit unsigned pixel values, 
% row, column and color information and also the number of images.
%
% Syntax:
% binary_vector(unsigned_integer_number)
%
% Example:
%
% >> binary_vector(234)
% 
% ans =
% 
%      0
%      1
%      0
%      1
%      0
%      1
%      1
%      1

out=zeros(8,1);
if ~in
    return;
else
    while(1)
        out(floor(log2(in))+1)=1;
        in= in - power(2,floor(log2(in)));
        if ~in
            break;end
    end
end